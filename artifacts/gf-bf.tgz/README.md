# GF BF — Group Voice Party App

Bangla + English voice rooms with chat, gifts, wallet, and Agora-ready tokens.

## Features

- Email register / login + guest mode
- Live rooms (create / join / seats)
- Room chat (Socket.IO realtime)
- Gifts + coins + daily bonus
- Profile (BN/EN)
- Agora RTC token API (`/api/rooms/:id/agora`)

## Render deploy

1. Push this folder to GitHub
2. New Web Service → connect repo
3. Set env:
   - `MONGO_URI` — your MongoDB Atlas URI
   - `JWT_SECRET` — random long string
   - `AGORA_APP_ID` / `AGORA_APP_CERTIFICATE`
   - `ADMIN_EMAIL` — optional
4. Start command: `npm start`

## Local

```bash
npm install
cp .env.example .env   # fill MONGO_URI etc
npm start
```

Open `http://localhost:3000`

## Notes

- **Phone OTP / Google native** needs your Firebase / OAuth client on mobile (Flutter next phase).
- This web build runs on Render free tier with Mongo + Agora.
- Mic uses browser `getUserMedia` for speaking animation; full multi-user audio uses Agora client SDK with the token from join.
