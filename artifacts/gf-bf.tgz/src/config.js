try { require("dotenv").config(); } catch (_) {}

module.exports = {
  port: process.env.PORT || 3000,
  mongoUri: process.env.MONGO_URI || "mongodb://127.0.0.1:27017/gfbf",
  jwtSecret: process.env.JWT_SECRET || "change-me-in-production",
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || "30d",
  agoraAppId: process.env.AGORA_APP_ID || "",
  agoraCertificate: process.env.AGORA_APP_CERTIFICATE || "",
  adminEmail: (process.env.ADMIN_EMAIL || "").toLowerCase(),
  nodeEnv: process.env.NODE_ENV || "development",
  clientOrigins: (process.env.CLIENT_ORIGINS || "*").split(",").map((s) => s.trim()),
};
