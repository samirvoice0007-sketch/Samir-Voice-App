const express = require("express");
const bcrypt = require("bcryptjs");
const User = require("../models/User");
const config = require("../config");
const { signToken, authRequired } = require("../middleware/auth");

const router = express.Router();

function hueFrom(str) {
  let n = 0;
  for (let i = 0; i < str.length; i++) n = (n + str.charCodeAt(i) * 17) % 360;
  return n;
}

router.post("/register", async (req, res) => {
  try {
    const { email, password, displayName, lang } = req.body || {};
    if (!email || !password || password.length < 6) {
      return res.status(400).json({ error: "Email and password (min 6) required" });
    }
    const exists = await User.findOne({ email: String(email).toLowerCase() });
    if (exists) return res.status(409).json({ error: "Email already registered" });
    const passwordHash = await bcrypt.hash(password, 10);
    const name = (displayName || email.split("@")[0] || "Star").slice(0, 32);
    const user = await User.create({
      email: String(email).toLowerCase(),
      passwordHash,
      displayName: name,
      avatarHue: hueFrom(email),
      lang: lang === "en" ? "en" : "bn",
      role: config.adminEmail && String(email).toLowerCase() === config.adminEmail ? "admin" : "user",
    });
    const token = signToken(user);
    res.json({ token, user: user.public() });
  } catch (e) {
    res.status(500).json({ error: e.message || "Register failed" });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) return res.status(400).json({ error: "Email and password required" });
    const user = await User.findOne({ email: String(email).toLowerCase() });
    if (!user || !user.passwordHash) return res.status(401).json({ error: "Invalid credentials" });
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return res.status(401).json({ error: "Invalid credentials" });
    const token = signToken(user);
    res.json({ token, user: user.public() });
  } catch (e) {
    res.status(500).json({ error: e.message || "Login failed" });
  }
});

/** Demo/guest login for testing without email (remove in strict production if needed) */
router.post("/guest", async (req, res) => {
  try {
    const name = String((req.body && req.body.displayName) || `Guest${Math.floor(Math.random() * 9000 + 1000)}`).slice(0, 24);
    const email = `guest_${Date.now()}_${Math.random().toString(36).slice(2, 8)}@gfbf.local`;
    const user = await User.create({
      email,
      displayName: name,
      avatarHue: Math.floor(Math.random() * 360),
      passwordHash: await bcrypt.hash(Math.random().toString(36), 8),
    });
    const token = signToken(user);
    res.json({ token, user: user.public() });
  } catch (e) {
    res.status(500).json({ error: e.message || "Guest failed" });
  }
});

router.get("/me", authRequired, async (req, res) => {
  res.json({ user: req.user.public() });
});

module.exports = router;
